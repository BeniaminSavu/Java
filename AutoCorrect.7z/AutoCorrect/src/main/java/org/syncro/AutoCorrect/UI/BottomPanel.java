package org.syncro.AutoCorrect.UI;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.border.MatteBorder;

public class BottomPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private SmartQuotesPanel smartQuotesPanel = new SmartQuotesPanel();
	private SingleQuoteCheckBoxPanel singleQuotePanel = new SingleQuoteCheckBoxPanel();
	private DoubleQuoteCheckBoxPanel doubleQuotePanel = new DoubleQuoteCheckBoxPanel();
	private JButton restoreDefaultsButton = new JButton("Restore Defaults");

	public void createGUI() {
		this.setLayout(new GridBagLayout());
		this.setBorder(new MatteBorder(0, 0, 1, 0, Color.BLUE));
		this.setBackground(Color.WHITE);

		GridBagConstraints gbc = new GridBagConstraints();

		addSmartQuotesPanel(gbc);
		addSingleQuotePanel(gbc);
		addDoubleQuotePanel(gbc);
		addRestoreDefaultsBUtton(gbc);
	}

	private void addSmartQuotesPanel(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 0;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridwidth = 2;
		smartQuotesPanel.createGUI();
		this.add(smartQuotesPanel, gbc);

	}

	private void addSingleQuotePanel(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 0;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 1;
		singleQuotePanel.createGUI();
		this.add(singleQuotePanel, gbc);
	}

	private void addDoubleQuotePanel(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 20;
		gbc.insets.top = 0;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 1;
		doubleQuotePanel.createGUI();
		this.add(doubleQuotePanel, gbc);

	}

	private void addRestoreDefaultsBUtton(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 0;
		gbc.insets.bottom = 5;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridwidth = 2;
		this.add(restoreDefaultsButton, gbc);

	}

}
