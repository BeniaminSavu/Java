package org.syncro.AutoCorrect.UI;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

public class ConfirmButtonsPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JButton okButton = new JButton("OK");
	private JButton applyButton = new JButton("Apply");
	private JButton cancelButton = new JButton("Cancel");

	public void createGUI() {
		this.setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();
		Dimension buttonDimension = new Dimension(70, 25);

		addOkButton(gbc, buttonDimension);
		addCancelButton(gbc, buttonDimension);
		addApplyButton(gbc, buttonDimension);

	}

	private void addOkButton(GridBagConstraints gbc, Dimension buttonDimension) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 0;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;
		okButton.setPreferredSize(buttonDimension);
		this.add(okButton, gbc);
	}

	private void addCancelButton(GridBagConstraints gbc, Dimension buttonDimension) {
		gbc.insets.right = 5;
		gbc.insets.left = 5;
		gbc.insets.top = 0;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;
		cancelButton.setPreferredSize(buttonDimension);
		this.add(cancelButton, gbc);

	}

	private void addApplyButton(GridBagConstraints gbc, Dimension buttonDimension) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 0;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;
		applyButton.setPreferredSize(buttonDimension);
		this.add(applyButton);

	}

}
