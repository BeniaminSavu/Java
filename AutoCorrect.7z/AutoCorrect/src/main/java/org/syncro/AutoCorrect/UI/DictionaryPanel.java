package org.syncro.AutoCorrect.UI;

import javax.swing.JPanel;

public class DictionaryPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	public void createGUI() {
		// TODO Auto-generated method stub

	}

}
