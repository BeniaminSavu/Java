package org.syncro.AutoCorrect.UI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;

public class DoubleQuoteCheckBoxPanel extends JPanel {

	private static final long serialVersionUID = 1L;
	private JCheckBox doubleQuotesCheckBox = new JCheckBox("Replace \"Double quotes\"");
	private JButton startDoubleQuoteButton = new JButton("\"");
	private JLabel startDoubleQuoteLabel = new JLabel("Start quote ");
	private JButton endDoubleQuoteButton = new JButton("\"");
	private JLabel endDoubleQuoteLabel = new JLabel("End quote");

	public void createGUI() {
		this.setBackground(Color.WHITE);
		this.setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();

		addDoubleQuoteCheckBox(gbc);
		addStartLabel(gbc);
		addStartButton(gbc);
		addEndLabel(gbc);
		addEndButton(gbc);

		addDoubleQuoteCheckBoxListener();

	}

	private void addDoubleQuoteCheckBoxListener() {
		doubleQuotesCheckBox.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					startDoubleQuoteButton.setEnabled(true);
					endDoubleQuoteButton.setEnabled(true);
				} else {
					startDoubleQuoteButton.setEnabled(false);
					endDoubleQuoteButton.setEnabled(false);
				}

			}
		});

	}

	private void addDoubleQuoteCheckBox(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 10;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 2;
		doubleQuotesCheckBox.setBackground(Color.WHITE);
		this.add(doubleQuotesCheckBox);

	}

	private void addStartLabel(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 30;
		gbc.insets.top = 10;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 1;
		this.add(startDoubleQuoteLabel, gbc);

	}

	private void addStartButton(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 10;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 1;
		startDoubleQuoteButton.setEnabled(false);
		startDoubleQuoteButton.setPreferredSize(new Dimension(40,25));
		this.add(startDoubleQuoteButton, gbc);
	}

	private void addEndLabel(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 30;
		gbc.insets.top = 10;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 1;
		this.add(endDoubleQuoteLabel, gbc);
	}

	private void addEndButton(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 10;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 1;
		endDoubleQuoteButton.setEnabled(false);
		endDoubleQuoteButton.setPreferredSize(new Dimension(40,25));
		this.add(endDoubleQuoteButton, gbc);
	}

}
