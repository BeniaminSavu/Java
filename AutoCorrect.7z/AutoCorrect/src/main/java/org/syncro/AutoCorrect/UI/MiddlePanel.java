package org.syncro.AutoCorrect.UI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;


import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JComboBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.JTextField;
import javax.swing.table.TableModel;

import org.syncro.AutoCorrect.jaxb.entities.Person;
import org.syncro.AutoCorrect.model.MyTableModel;

public class MiddlePanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JComboBox<String> language;
	private JTable table;
	private JLabel icon = new JLabel("", new ImageIcon("src/main/resources/icon.png"), JLabel.LEFT);
	private ButtonPanel buttonPanel = new ButtonPanel();
	private JPopupMenu contextualMenu = new JPopupMenu();

	public void createGUI() {
		setBackground(Color.WHITE);
		setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();

		addSelectLanguageLabel(gbc);
		addLanguageComboBox(gbc);
		addInformationIcon(gbc);
		addTable(gbc);
		addContextualMenu();
		addButtonsPanel(gbc);

		addLangugeComboBoxListener();
		addIconListener();
		addTableListener();
		addRemoveButtonListener();
		addButtonAddListener();

	}

	private void addButtonAddListener() {
		buttonPanel.getAddButton().addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				final JDialog dialog = new JDialog();
				dialog.setLayout(new FlowLayout());

				final JTextField name = new JTextField("Name");
				name.setPreferredSize(new Dimension(150, 25));
				dialog.add(name);

				final JTextField salary = new JTextField("Salary");
				salary.setPreferredSize(new Dimension(150, 25));
				dialog.add(salary);

				JButton ok = new JButton("OK");
				ok.setPreferredSize(new Dimension(70, 25));
				ok.addActionListener(new ActionListener() {

					public void actionPerformed(ActionEvent e) {
						String nameFromUser = name.getText();
						String salaryFromUser = salary.getText();

						Person person = new Person();
						person.setName(nameFromUser);
						person.setSalary(salaryFromUser);

						TableModel model = table.getModel();
						MyTableModel myModel = (MyTableModel) model;
						myModel.addEntry(person);
						myModel.fireTableDataChanged();
						dialog.dispose();
					}
				});
				dialog.add(ok);

				JButton cancel = new JButton("Cancel");
				cancel.setPreferredSize(new Dimension(70, 25));
				dialog.add(cancel);

				dialog.setIconImage(null);
				dialog.setTitle("Add Entry");
				dialog.setSize(new Dimension(350, 125));
				dialog.setLocationRelativeTo(null);
				dialog.setVisible(true);

			}
		});

	}

	private void addLangugeComboBoxListener() {
		language.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					String item = (String) e.getItem();
					MyTableModel dataModel = (MyTableModel) table.getModel();
					dataModel.setFile(item + ".xml");
					dataModel.readFromFile();
					table.setModel(dataModel);
					dataModel.fireTableDataChanged();
				}

			}
		});

	}

	private void addRemoveButtonListener() {
		buttonPanel.getRemoveButton().addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				int selectedRow[] = table.getSelectedRows();
				TableModel model = table.getModel();
				MyTableModel myModel = (MyTableModel) model;

				if (selectedRow.length > 0) {
					for (int i = selectedRow.length - 1; i >= 0; i--) {
						int viewRowIndex = selectedRow[i];
						int convertRowIndexToModel = table.convertRowIndexToModel(viewRowIndex);
						myModel.removeRow(convertRowIndexToModel);

					}
				}
				myModel.fireTableDataChanged();

			}
		});

	}

	private void addTableListener() {
		table.addMouseListener(new MouseAdapter() {
			@Override
			public void mousePressed(MouseEvent e) {

				if (e.getButton() == MouseEvent.BUTTON1) {
					buttonPanel.getRemoveButton().setEnabled(true);
				}

				if (e.getButton() == MouseEvent.BUTTON2) {
					System.err.println("SCROLL");
				}

				if (e.getButton() == MouseEvent.BUTTON3 && e.getClickCount() == 1) {
					System.err.println("DREAPTA");

					int clickedRow = table.rowAtPoint(e.getPoint());
					if (clickedRow >= 0 && clickedRow < table.getRowCount()) {
						table.setRowSelectionInterval(clickedRow, clickedRow);
					} else {
						table.clearSelection();
					}
					contextualMenu.show(table, e.getX(), e.getY());
				}

			}
		});

	}

	private void addIconListener() {
		icon.addMouseListener(new MouseAdapter() {

			@Override
			public void mousePressed(MouseEvent e) {
				if (e.getButton() == MouseEvent.BUTTON1) {
					JLabel label = new JLabel(
							"<HTML>The available languages are detected based on a set of specified dictionaries used<br> for the automatic correction. To add more dictionaries, see the \"AutoCorrect /<br> Dictionaries\" options sub-page.</HTML>");
					label.setBorder(BorderFactory.createLineBorder(Color.GRAY));
					JOptionPane.showMessageDialog(null, label);

				}
			}
		});

	}

	private void addSelectLanguageLabel(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 0;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;
		this.add(new JLabel("Replacements for language: "), gbc);

	}

	private void addLanguageComboBox(GridBagConstraints gbc) {
		gbc.insets.right = 10;
		gbc.insets.left = 10;
		gbc.insets.top = 0;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 0;

		String languages[] = { "C", "C++", "C#", "Java", "PHP", "Python" };
		language = new JComboBox<String>(languages);
		this.add(language, gbc);
	}

	private void addInformationIcon(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 0;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;
		this.add(icon, gbc);
	}

	private void addTable(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 10;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.BOTH;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridwidth = 3;

		MyTableModel model = new MyTableModel();
		model.setFile("C.xml");
		model.readFromFile();
		table = new JTable(model);
		table.setAutoCreateRowSorter(true);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		table.setPreferredScrollableViewportSize(new Dimension(scrollPane.getWidth(), scrollPane.getHeight()));
		this.add(scrollPane, gbc);
	}

	private void addContextualMenu() {
		JMenuItem jMenuItem = new JMenuItem("Delete");
		jMenuItem.addActionListener(new ActionListener() {

			public void actionPerformed(ActionEvent e) {
				int selectedRow[] = table.getSelectedRows();
				TableModel model = table.getModel();
				MyTableModel myModel = (MyTableModel) model;

				if (selectedRow.length > 0) {
					for (int i = selectedRow.length - 1; i >= 0; i--) {
						int viewRowIndex = selectedRow[i];
						int convertRowIndexToModel = table.convertRowIndexToModel(viewRowIndex);
						myModel.removeRow(convertRowIndexToModel);

					}
				}
				myModel.fireTableDataChanged();

			}
		});
		contextualMenu.add(jMenuItem);

	}

	private void addButtonsPanel(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 3;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 3;
		buttonPanel.createGUI();
		this.add(buttonPanel, gbc);

	}

	private MyTableModel readFile(String file) {
		/*
		 * SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
		 * List<Person> persons = null; try { SAXParser saxParser =
		 * saxParserFactory.newSAXParser(); PersonHandler handler = new
		 * PersonHandler();
		 * 
		 * File xmlFile = new File("src/main/resources/" + file);
		 * saxParser.parse(xmlFile, handler); persons = handler.getPersons();
		 * 
		 * } catch (Exception e) { e.printStackTrace(); }
		 */
		return null;
	}

}
