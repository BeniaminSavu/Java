package org.syncro.AutoCorrect.UI;

import java.awt.Color;
import java.awt.Dimension;
import java.awt.FlowLayout;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.ItemEvent;
import java.awt.event.ItemListener;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JDialog;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

public class SingleQuoteCheckBoxPanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JCheckBox singleQuotesCheckBox = new JCheckBox("Replace 'Single quotes'");
	private JButton startSingleQuoteButton = new JButton("'");
	private JLabel startSingleQuoteLabel = new JLabel("Start quote ");
	private JButton endSingleQuoteButton = new JButton("'");
	private JLabel endSingleQuoteLabel = new JLabel("End quote");

	public void createGUI() {
		this.setBackground(Color.WHITE);
		this.setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();

		addSingleQuoteCheckBox(gbc);
		addStartLabel(gbc);
		addStartButton(gbc);
		addEndLabel(gbc);
		addEndButton(gbc);

		addSingleQuoteCheckBoxListenr();
		addStartSingleQuoteButtonListener();
		addEndSingleQuoteButtonListener();
	}

	private void addEndSingleQuoteButtonListener() {
		endSingleQuoteButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				final JDialog dialog = new JDialog();
				dialog.setLayout(new FlowLayout());

				final JTextField startSingleQuote = new JTextField("end");
				startSingleQuote.setPreferredSize(new Dimension(150, 25));
				dialog.add(startSingleQuote);

				JButton ok = new JButton("OK");
				ok.setPreferredSize(new Dimension(70, 25));
				ok.addActionListener(new ActionListener() {

					public void actionPerformed(ActionEvent e) {
						String userInput = startSingleQuote.getText();
						if(userInput.length() == 1){
							endSingleQuoteButton.setText(startSingleQuote.getText());
						}
						dialog.dispose();
					}
				});
				dialog.add(ok);

				JButton cancel = new JButton("Cancel");
				cancel.setPreferredSize(new Dimension(70, 25));
				cancel.addActionListener(new ActionListener() {
					
					public void actionPerformed(ActionEvent e) {
						dialog.dispose();
						
					}
				});
				dialog.add(cancel);

				dialog.setIconImage(null);
				dialog.setTitle("Add Entry");
				dialog.setSize(new Dimension(200, 125));
				dialog.setLocationRelativeTo(null);
				dialog.setVisible(true);
				
			}
		});
	}

	private void addStartSingleQuoteButtonListener() {
		startSingleQuoteButton.addActionListener(new ActionListener() {
			
			public void actionPerformed(ActionEvent e) {
				final JDialog dialog = new JDialog();
				dialog.setLayout(new FlowLayout());

				final JTextField startSingleQuote = new JTextField("start");
				startSingleQuote.setPreferredSize(new Dimension(150, 25));
				dialog.add(startSingleQuote);

				JButton ok = new JButton("OK");
				ok.setPreferredSize(new Dimension(70, 25));
				ok.addActionListener(new ActionListener() {

					public void actionPerformed(ActionEvent e) {
						String userInput = startSingleQuote.getText();
						if(userInput.length() == 1){
							startSingleQuoteButton.setText(startSingleQuote.getText());
						}
						dialog.dispose();
					}
				});
				dialog.add(ok);

				JButton cancel = new JButton("Cancel");
				cancel.setPreferredSize(new Dimension(70, 25));
				cancel.addActionListener(new ActionListener() {
					
					public void actionPerformed(ActionEvent e) {
						dialog.dispose();
						
					}
				});
				dialog.add(cancel);

				dialog.setIconImage(null);
				dialog.setTitle("Add Entry");
				dialog.setSize(new Dimension(200, 125));
				dialog.setLocationRelativeTo(null);
				dialog.setVisible(true);
				
			}
		});
		
	}

	private void addSingleQuoteCheckBoxListenr() {
		singleQuotesCheckBox.addItemListener(new ItemListener() {

			public void itemStateChanged(ItemEvent e) {
				if (e.getStateChange() == ItemEvent.SELECTED) {
					startSingleQuoteButton.setEnabled(true);
					endSingleQuoteButton.setEnabled(true);
				} else {
					startSingleQuoteButton.setEnabled(false);
					endSingleQuoteButton.setEnabled(false);
				}

			}
		});

	}

	private void addSingleQuoteCheckBox(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 10;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 2;
		singleQuotesCheckBox.setBackground(Color.WHITE);
		this.add(singleQuotesCheckBox);

	}

	private void addStartLabel(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 30;
		gbc.insets.top = 10;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 1;
		this.add(startSingleQuoteLabel, gbc);

	}

	private void addStartButton(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 10;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.gridx = 1;
		gbc.gridy = 1;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 1;
		startSingleQuoteButton.setEnabled(false);
		startSingleQuoteButton.setPreferredSize(new Dimension(40,25));
		this.add(startSingleQuoteButton, gbc);
	}

	private void addEndLabel(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 30;
		gbc.insets.top = 10;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 1;
		this.add(endSingleQuoteLabel, gbc);
	}

	private void addEndButton(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 10;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.gridx = 1;
		gbc.gridy = 2;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 1;
		endSingleQuoteButton.setEnabled(false);
		endSingleQuoteButton.setPreferredSize(new Dimension(40,25));
		this.add(endSingleQuoteButton, gbc);
	}
}
