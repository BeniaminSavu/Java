package org.syncro.AutoCorrect.UI.constant;

public class PanelPadding {
	public static final int LEFT = 10;
	public static final int RIGHT = 10;
	public static final int TOP = 5;
	public static final int BOTTOM = 10;
}
