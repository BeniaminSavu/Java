package org.syncro.AutoCorrect.jaxb.entities;

public class Serializer {

}
