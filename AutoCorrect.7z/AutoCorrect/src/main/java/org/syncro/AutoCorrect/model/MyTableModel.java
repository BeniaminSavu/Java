package org.syncro.AutoCorrect.model;

import java.io.File;
import java.util.List;

import javax.swing.table.AbstractTableModel;
import javax.xml.bind.JAXBContext;
import javax.xml.bind.JAXBException;
import javax.xml.bind.Marshaller;
import javax.xml.bind.Unmarshaller;

import org.syncro.AutoCorrect.jaxb.entities.Person;
import org.syncro.AutoCorrect.jaxb.entities.Persons;

public class MyTableModel extends AbstractTableModel {

	/**
	* 
	*/
	private static final long serialVersionUID = 1L;

	public String[] columnNames = { "Name", "Salary" };

	private List<Person> persons;

	private String file;
	
	public MyTableModel() {

	}

	public MyTableModel(List<Person> persons) {
		this.persons = persons;
	}

	public int getColumnCount() {
		return columnNames.length;
	}

	public int getRowCount() {
		int size;
		if (persons == null) {
			size = 0;
		} else {
			size = persons.size();
		}
		return size;
	}

	public Object getValueAt(int row, int col) {
		Object temp = null;
		if (col == 0) {
			temp = persons.get(row).getName();
		} else if (col == 1) {
			temp = persons.get(row).getSalary();
		}
		return temp;
	}

	// needed to show column names in JTable
	public String getColumnName(int col) {
		return columnNames[col];
	}

	public Class getColumnClass(int col) {
		return String.class;
	}

	public void removeRow(int rowIndexToRemove) {
		if (persons != null && persons.size() > 0 && persons.size() > rowIndexToRemove) {
			persons.remove(rowIndexToRemove);
		}
		try {
			persist();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}

	public void addEntry(Person person) {
		if (person != null) {
			persons.add(person);
		}
		try {
			persist();
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}

	}
	
	private void persist() throws JAXBException {
		Persons pers = new Persons();
		pers.setPersons(persons);
		JAXBContext jaxbContext = JAXBContext.newInstance(Persons.class);
		Marshaller jaxbMarshaller = jaxbContext.createMarshaller();

		jaxbMarshaller.setProperty(Marshaller.JAXB_FORMATTED_OUTPUT, true);

		// Marshal the employees list in file
		jaxbMarshaller.marshal(pers, new File("src/main/resources/" + file));

	}

	public void readFromFile() {
		JAXBContext jaxbContext;
		Persons personsFromFile = null;
		try {
			jaxbContext = JAXBContext.newInstance(Persons.class);
			Unmarshaller jaxbUnmarshaller = jaxbContext.createUnmarshaller();
			personsFromFile = (Persons) jaxbUnmarshaller.unmarshal(new File("src/main/resources/" + file));
		} catch (JAXBException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		persons = personsFromFile.getPersons();

	}
	
	public void setFile(String file){
		this.file = file;
	}
}