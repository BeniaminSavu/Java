package org.syncro.demo;

import java.awt.Dimension;

import javax.swing.JFrame;

import org.syncro.demo.UI.MainWindow;

public class App {
	public static void main(String[] args) {
		MainWindow window = new MainWindow("Demo application");
		
		window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);  
		window.setSize(new Dimension(600, 800));
		window.setLocationRelativeTo(null);
		window.setVisible(true);
		
	}
}
