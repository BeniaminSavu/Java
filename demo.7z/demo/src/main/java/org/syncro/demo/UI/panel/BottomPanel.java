package org.syncro.demo.UI.panel;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.JButton;
import javax.swing.JPanel;

import org.syncro.demo.UI.panel.bottom.DoubleQuoteCheckBoxPanel;
import org.syncro.demo.UI.panel.bottom.SingleQuoteCheckBoxPanel;

public class BottomPanel {
	private JPanel panel = new JPanel(new GridBagLayout());
	private DoubleQuoteCheckBoxPanel doubleQuotePanel = new DoubleQuoteCheckBoxPanel();
	private SingleQuoteCheckBoxPanel singleQuotePanel = new SingleQuoteCheckBoxPanel();
	private JButton restoreDefaultsButton = new JButton("Restore Defaults");

	public BottomPanel() {
		init();
	}

	private void init() {
		//panel.setBorder(BorderFactory.createTitledBorder("Bottom-Panel"));
		GridBagConstraints gbc = new GridBagConstraints();

		// add Single Quote Panel
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.NONE;
		panel.add(singleQuotePanel.getPanel());

		// add Double Quote Panel
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.gridwidth = 1;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.NONE;
		panel.add(doubleQuotePanel.getPanel());

		// Restore Button
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridwidth = 3;
		gbc.anchor = GridBagConstraints.EAST;
		gbc.fill = GridBagConstraints.NONE;
		panel.add(restoreDefaultsButton, gbc);
	}

	public JPanel getPanel() {
		return panel;
	}

}
