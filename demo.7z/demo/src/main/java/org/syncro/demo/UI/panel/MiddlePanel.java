package org.syncro.demo.UI.panel;

import java.awt.Dimension;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.File;
import java.util.List;

import javax.swing.BorderFactory;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JPopupMenu;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.xml.parsers.SAXParser;
import javax.xml.parsers.SAXParserFactory;

import org.syncro.demo.UI.entities.MyTableModel;
import org.syncro.demo.UI.panel.middle.ButtonPanel;
import org.syncro.demo.listener.RemoveButtonListener;
import org.syncro.demo.sax.PersonHandler;
import org.syncro.demo.sax.entities.Person;

public class MiddlePanel  {

	private JPanel panel = new JPanel(new GridBagLayout());
	private JComboBox<String> language;
	private JTable table;
	private ButtonPanel buttonPanel = new ButtonPanel();

	public MiddlePanel() {
		init();
	}

	private void init() {
		//panel.setBorder(BorderFactory.createTitledBorder("Middle-Panel"));

		GridBagConstraints gbc = new GridBagConstraints();

		// add selectLanguage label
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.insets.left = PanelPadding.LEFT_PADDING;
		gbc.insets.right = PanelPadding.RIGHT_PADDING;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		panel.add(new JLabel("Replacements for language: "), gbc);

		// add language combo box
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.insets.left = PanelPadding.LEFT_PADDING;
		gbc.insets.right = PanelPadding.RIGHT_PADDING;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		String languages[] = { "C", "C++", "C#", "Java", "PHP", "Python" };
		language = new JComboBox<String>(languages);
		panel.add(language, gbc);

		// add table
		gbc.gridx = 0;
		gbc.gridy = 1;
		gbc.gridwidth = 2;
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.insets.left = PanelPadding.LEFT_PADDING;
		gbc.insets.right = PanelPadding.RIGHT_PADDING;
		gbc.fill = GridBagConstraints.BOTH;
		gbc.anchor = GridBagConstraints.WEST;
		MyTableModel model = readData();
		table = new JTable(model);
		table.setAutoCreateRowSorter(true);
		JScrollPane scrollPane = new JScrollPane(table);
		scrollPane.setVerticalScrollBarPolicy(JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED);
		table.setPreferredScrollableViewportSize(new Dimension(scrollPane.getWidth(), scrollPane.getHeight()));
		panel.add(scrollPane, gbc);
		
		table.addMouseListener(new MouseAdapter() {
			
			@Override
			public void mousePressed(MouseEvent e) {
				
				if (e.getButton() == MouseEvent.BUTTON1 && 
						e.getClickCount() == 2) {
					System.err.println("STANGA de 2 ori");
				}
				
				if (e.getButton() == MouseEvent.BUTTON2) {
					System.err.println("SCROLL");
				}
				
				if (e.getButton() == MouseEvent.BUTTON3 &&
						e.getClickCount() == 1) {
					System.err.println("DREAPTA");
					
					JPopupMenu contextualMenu = new JPopupMenu();
					
					JMenuItem jMenuItem = new JMenuItem("Sterge");
					jMenuItem.addActionListener(new RemoveButtonListener(table));
					
					
					contextualMenu.add(jMenuItem);
					
					contextualMenu.show(table, e.getX(), e.getY());
				}
				
			}
			
		});

		// add the buttons panel
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.gridwidth = 2;
		gbc.weightx = 0;
		gbc.weighty = 0;
		gbc.insets.left = PanelPadding.LEFT_PADDING;
		gbc.insets.right = PanelPadding.RIGHT_PADDING;
		gbc.fill = GridBagConstraints.NONE;
		gbc.anchor = GridBagConstraints.EAST;
		panel.add(buttonPanel.getPanel(), gbc);

		
		buttonPanel.getRemoveButton().addActionListener(new RemoveButtonListener(table));
	}

	private MyTableModel readData() {
		SAXParserFactory saxParserFactory = SAXParserFactory.newInstance();
		List<Person> persons = null;
		try {
			SAXParser saxParser = saxParserFactory.newSAXParser();
			PersonHandler handler = new PersonHandler();

			File xmlFile = new File("src/main/resources/persons.xml");
			saxParser.parse(xmlFile, handler);
			persons = handler.getPersons();

			for (Person person : persons) {
				System.out.println(person);
			}

		} catch (Exception e) {
			e.printStackTrace();
		}
		return new MyTableModel(persons);

	}

	public JPanel getPanel() {
		return panel;
	}

	public JTable getTable() {
		return table;
	}

	

}
