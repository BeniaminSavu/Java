package org.syncro.demo.UI.panel;

public class PanelPadding {
	public static final int LEFT_PADDING = 10;
	public static final int RIGHT_PADDING = 10;
}
