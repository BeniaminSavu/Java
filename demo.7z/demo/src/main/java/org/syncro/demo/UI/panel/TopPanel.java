package org.syncro.demo.UI.panel;

import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;
import java.util.Vector;

import javax.swing.BorderFactory;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.table.AbstractTableModel;

public class TopPanel {
	private JPanel panel = new JPanel(new GridBagLayout());
	private JCheckBox autocorrectCheckBox = new JCheckBox("<html>Enable AutoCorrect</html>");
	private JCheckBox additionalSugestionsCheckBox = new JCheckBox("<html>Use additional suggestions</html>");

	public TopPanel() {
		init();
	}

	private void init() {
		//panel.setBorder(BorderFactory.createTitledBorder("Top-Panel"));

		GridBagConstraints gbc = new GridBagConstraints();

		// add auto correct check box
		gbc.weightx = 1;
		gbc.weighty = 1;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.insets.left = PanelPadding.LEFT_PADDING;
		gbc.insets.right = PanelPadding.RIGHT_PADDING;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		panel.add(autocorrectCheckBox, gbc);

		// add auto additional suggestions check box
		gbc.gridy = 1;
		gbc.gridx = 0;
		gbc.insets.left = PanelPadding.LEFT_PADDING + 40;
		gbc.insets.right = PanelPadding.RIGHT_PADDING;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		panel.add(additionalSugestionsCheckBox, gbc);

		// add info label
		gbc.gridx = 0;
		gbc.gridy = 2;
		gbc.insets.left = PanelPadding.LEFT_PADDING;
		gbc.insets.right = PanelPadding.RIGHT_PADDING;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		ImageIcon icon = new ImageIcon("src/main/resources/icon.png");
		panel.add(new JLabel(
				"<html>The AutoCorrect feature uses the same language options and the same  ignored elements as the spell checker</html>",
				icon, JLabel.LEFT), gbc);

	}

	public JPanel getPanel() {
		return panel;
	}

}
