package org.syncro.demo.UI.panel.middle;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JPanel;
import javax.swing.JTable;
import javax.swing.table.TableModel;

import org.syncro.demo.UI.entities.MyTableModel;
import org.syncro.demo.UI.panel.MiddlePanel;
import org.syncro.demo.listener.RemoveButtonListener;

public class ButtonPanel  {

	private JPanel panel = new JPanel();
	private JButton addButton = new JButton("Add");
	private JButton removeButton = new JButton("Remove");
	
	public ButtonPanel(){
		init();
	}
	
	private void init() {
		//add the addButton and the remove button
		panel.add(addButton);
		panel.add(removeButton);
		
	}

	public JPanel getPanel() {
		return panel;
	}
	
	public JButton getRemoveButton(){
		return removeButton;
	}

}
