package org.syncro.demo.listener;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JTable;
import javax.swing.table.TableModel;

import org.syncro.demo.UI.entities.MyTableModel;

public class RemoveButtonListener implements ActionListener {

	private JTable table;

	public RemoveButtonListener(JTable table) {;
		this.table = table;
	}

	public void actionPerformed(ActionEvent e) {
		
		int selectedRow[] = table.getSelectedRows();
		TableModel model = table.getModel();
		MyTableModel myModel = (MyTableModel)model;
		
		if (selectedRow.length > 0) {
			for(int i= selectedRow.length - 1; i >= 0 ; i--){
				int viewRowIndex = selectedRow[i];
				System.err.println("VIEW TO INDEX: " + viewRowIndex);
				if (viewRowIndex != -1) {
					int convertRowIndexToModel = table.convertRowIndexToModel(viewRowIndex);
					if (convertRowIndexToModel != -1) {
						System.err.println("CONVERTED: " + convertRowIndexToModel);
						myModel.fireTableRowsDeleted(convertRowIndexToModel, convertRowIndexToModel);
						myModel.removeRow(convertRowIndexToModel);
					}
				}
			}
			myModel.fireTableDataChanged();
		}
	}

}
