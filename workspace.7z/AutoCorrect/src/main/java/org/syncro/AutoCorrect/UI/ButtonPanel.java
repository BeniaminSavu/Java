package org.syncro.AutoCorrect.UI;

import javax.swing.JPanel;

public class ButtonPanel extends JPanel {

}
