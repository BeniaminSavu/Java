package org.syncro.AutoCorrect.UI;

import javax.swing.JPanel;

public class ConfirmButtonsPanel extends JPanel {

	public void createGUI() {
		// TODO Auto-generated method stub

	}

}
