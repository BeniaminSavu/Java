package org.syncro.AutoCorrect.UI;

import java.awt.Color;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;

import javax.swing.ImageIcon;
import javax.swing.JComboBox;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTable;

public class MiddlePanel extends JPanel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private JComboBox<String> language;
	private JTable table;
	private ButtonPanel buttonPanel = new ButtonPanel();

	public void createGUI() {
		setBackground(Color.WHITE);
		setLayout(new GridBagLayout());

		GridBagConstraints gbc = new GridBagConstraints();
		
		addSelectLanguageLabel(gbc);
		addLanguageComboBox(gbc);
		addInformationIcon(gbc);
		
	}

	private void addSelectLanguageLabel(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 0;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 0;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;
		this.add(new JLabel("Replacements for language: "), gbc);
		
	}
	
	private void addLanguageComboBox(GridBagConstraints gbc) {
		gbc.insets.right = 10;
		gbc.insets.left = 10;
		gbc.insets.top = 0;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 1;
		gbc.gridy = 0;
		gbc.weightx = 1;
		gbc.weighty = 0;
		
		String languages[] = { "C", "C++", "C#", "Java", "PHP", "Python" };
		language = new JComboBox<String>(languages);
		this.add(language, gbc);
	}

	private void addInformationIcon(GridBagConstraints gbc) {
		gbc.insets.right = 0;
		gbc.insets.left = 0;
		gbc.insets.top = 0;
		gbc.insets.bottom = 0;
		gbc.fill = GridBagConstraints.HORIZONTAL;
		gbc.anchor = GridBagConstraints.WEST;
		gbc.gridx = 2;
		gbc.gridy = 0;
		gbc.weightx = 0;
		gbc.weighty = 0;

		JLabel icon = new JLabel("", new ImageIcon("src/main/resources/icon.png"), JLabel.LEFT);
		this.add(icon, gbc);
	}

}
